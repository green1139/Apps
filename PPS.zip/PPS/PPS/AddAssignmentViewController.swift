//
//  AddAssignmentViewController.swift
//  PPS
//
//  Created by Siddhant Pagariya on 6/16/15.
//  Copyright © 2015 Siddhant Pagariya. All rights reserved.
//

import UIKit

class AddAssignmentViewController: UIViewController
{
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var assignmentName: UITextField!
    @IBOutlet weak var hour: UITextField!
    @IBAction func addAssignment(sender: AnyObject)
    {
        button.transform = CGAffineTransformMakeScale(1.5, 1.5)
        UIView.animateWithDuration(2.0, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 10.0, options: UIViewAnimationOptions.AllowUserInteraction, animations: { () -> Void in
            self.button.transform = CGAffineTransformIdentity
            }, completion: nil)
        if (assignmentName.text != "" && hour.text != "")
        {
            let dict = ["assignment":assignmentName.text!, "hour":hour.text!]
            assignments.append(dict)
            NSUserDefaults.standardUserDefaults().setObject(assignments, forKey: "assignments")
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
    @IBOutlet weak var date:UILabel!
    override func viewDidLoad() {
        date.text = ""
    }
    override func viewDidAppear(animated: Bool) {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateStyle = NSDateFormatterStyle.LongStyle
        date.text = "Today is " + dateFormatter.stringFromDate(NSDate()) + ". "
        dateFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        dateFormatter.dateStyle = NSDateFormatterStyle.NoStyle
        date.text = date.text! + "And, the time right now is " + dateFormatter.stringFromDate(NSDate()) + "."
    }
}
