//
//  AssignmentViewController.swift
//  PPS
//
//  Created by Siddhant Pagariya on 6/15/15.
//  Copyright © 2015 Siddhant Pagariya. All rights reserved.
//

import UIKit

var assignments = [["assignment":String(), "hour":String()]]
var assignmentCellRow = 0
class AssignmentViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var assignmentTable: UITableView!
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return assignments.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "AssignmentCell")
        cell.textLabel!.text = assignments[indexPath.item]["assignment"]
        cell.detailTextLabel!.text = assignments[indexPath.item]["hour"]
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if (NSUserDefaults.standardUserDefaults().objectForKey("assignments") != nil)
        {
            assignments = NSUserDefaults.standardUserDefaults().objectForKey("assignments") as! [[String:String]]
        }
        else
        {
            assignments.removeAll()
            NSUserDefaults.standardUserDefaults().setObject(assignments, forKey: "assignments")
        }
    }
    override func viewDidAppear(animated: Bool) {
        if (NSUserDefaults.standardUserDefaults().objectForKey("assignments") != nil)
        {
            assignments = NSUserDefaults.standardUserDefaults().objectForKey("assignments") as! [[String:String]]
        }
        else
        {
            NSUserDefaults.standardUserDefaults().setObject(assignments, forKey: "assignments")
        }
        assignmentTable.reloadData()
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath)
    {
        if (editingStyle == UITableViewCellEditingStyle.Delete)
        {
            assignments.removeAtIndex(indexPath.row)
            NSUserDefaults.standardUserDefaults().setObject(assignments, forKey: "assignments")
            assignmentTable.reloadData()
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let VC = storyboard?.instantiateViewControllerWithIdentifier("ChangeAssignmentViewController")
        assignmentCellRow = indexPath.row
        self.navigationController?.pushViewController(VC!, animated: true)
    }

}
