//
//  AddSubjectViewController.swift
//  PPS
//
//  Created by Siddhant Pagariya on 6/30/15.
//  Copyright © 2015 Siddhant Pagariya. All rights reserved.
//

import UIKit

class AddSubjectViewController: UIViewController, UIPopoverPresentationControllerDelegate , SwiftColorPickerDelegate {
    var subjectColor = UIColor(red: CGFloat(255), green: CGFloat(255), blue: CGFloat(255), alpha: CGFloat(1))
    
    @IBOutlet weak var subject: UITextField!
    @IBOutlet weak var colorButton: UIButton!
    @IBAction func showColorPickerProgrammatically(sender: UIButton)
    {
        let colorPickerVC = SwiftColorPickerViewController()
        colorPickerVC.delegate = self
        colorPickerVC.modalPresentationStyle = .Popover
        let popVC = colorPickerVC.popoverPresentationController!;
        popVC.sourceRect = sender.frame
        popVC.sourceView = self.view
        popVC.permittedArrowDirections = .Any;
        popVC.delegate = self;
        
        self.presentViewController(colorPickerVC, animated: true, completion: {
            print("View Controller Presented.");
        })
    }
    @IBAction func addSubject(sender: AnyObject) {
        if (subject.text != "")
        {
            //let colors = CGColorGetComponents(subjectColor.CGColor)
            var r:CGFloat = 0
            var g:CGFloat = 0
            var b:CGFloat = 0
            var a:CGFloat = 0
            //subjectColor.getRed(&r, green: &g, blue: &b, alpha: &a)
            //print("\(Float(r)*255.0) , \(Float(g)*255.0), \(Float(b)*255.0)")
            //let dict:Dictionary<String, AnyObject> = ["subject":subject.text!, "red":(Float(r)*255.0), "blue":(Float(b)*255.0), "green":(Float(g)*255.0)]
            //subjects.append(dict)
            //NSUserDefaults.standardUserDefaults().setObject(subjects, forKey: "subjects")
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
    }
    
    // MARK: popover presentation delegates
    
    // this enables pop over on iphones
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        
        return UIModalPresentationStyle.None
    }
    
    // MARK: Color Picker Delegate
    
    func colorSelectionChanged(selectedColor color: UIColor) {
        
        colorButton.setTitleColor(color, forState: UIControlState.Normal)
        subject.textColor = color
        subjectColor = color
    }
}
