//
//  iOS_Swift_ColorPicker.h
//  iOS_Swift_ColorPicker
//
//  Created by Christian Zimmermann on 03/03/15.
//  Copyright (c) 2015 Christian Zimmermann. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iOS_Swift_ColorPicker.
FOUNDATION_EXPORT double iOS_Swift_ColorPickerVersionNumber;

//! Project version string for iOS_Swift_ColorPicker.
FOUNDATION_EXPORT const unsigned char iOS_Swift_ColorPickerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOS_Swift_ColorPicker/PublicHeader.h>



